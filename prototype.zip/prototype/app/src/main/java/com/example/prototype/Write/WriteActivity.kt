package com.example.prototype.Write

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.prototype.MainActivity
import com.example.prototype.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_write.*

class WriteActivity : AppCompatActivity() {

    private lateinit var nickname : String
    private lateinit var auth : FirebaseAuth
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_write)

        auth = FirebaseAuth.getInstance()

        val docRef = db.collection("users").document(auth.currentUser?.uid.toString())

        //닉네임 받아서 admin이랑 일반 유저랑 구분
        docRef.get().addOnSuccessListener { documentSnapshot ->

            nickname = documentSnapshot.get("nickname") as String

        }


        //글쓰기 구현
         write_save.setOnClickListener {

            val form = hashMapOf(

                "writer" to nickname,
                "title" to write_title.text.toString(),
                "content" to write_content.text.toString()

            )

            db.collection("write")
                .add(form)
                .addOnSuccessListener {

                    Toast.makeText(this, "글쓰기 성공", Toast.LENGTH_LONG).show()
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)

                    finish()

                }
                .addOnFailureListener {
                    Toast.makeText(this, "글쓰기 실패", Toast.LENGTH_LONG).show()
                }
        }

        //취소
        write_cancel.setOnClickListener{

            val intent = Intent(this , MainActivity::class.java)
            startActivity(intent)

            finish()

        }


    }
}
