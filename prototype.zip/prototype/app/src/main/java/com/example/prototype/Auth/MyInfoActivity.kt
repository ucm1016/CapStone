package com.example.prototype.Auth

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log.d
import android.view.ContextThemeWrapper
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.prototype.MainActivity
import com.example.prototype.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_join.*
import kotlinx.android.synthetic.main.activity_my_info.*

class MyInfoActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    private lateinit var auth : FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_info)

        FirebaseAuth.getInstance().signOut()

        auth = FirebaseAuth.getInstance()

        val doRef = db.collection("users").document(auth.currentUser?.uid.toString())

        doRef.get().addOnSuccessListener{documentSnapshot->

            nickname_area.setText(documentSnapshot.get("nickname").toString())

        }

        //로그아웃
        logout_bt.setOnClickListener {

            val builder = AlertDialog.Builder(
                ContextThemeWrapper
                    (this, R.style.Theme_AppCompat_Light_Dialog)
            )

            builder.setTitle("로그아웃")
            builder.setMessage("로그아웃 하시겠습니까?")
            builder.setPositiveButton("로그아웃") { dialog, which ->
                Toast.makeText(this, "완료", Toast.LENGTH_LONG).show()

                val intent = Intent(this , MainActivity::class.java)
                startActivity(intent)
            }
            builder.setNegativeButton("취소") { dialog, which ->
                Toast.makeText(this, "취소", Toast.LENGTH_LONG).show()
            }

            builder.show()

            FirebaseAuth.getInstance().signOut()


        }
    }
}
